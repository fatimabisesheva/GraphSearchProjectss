import java.util.*;

public class WeightedGraph {
    private Map<Vertex, Vertex> vertices = new HashMap<>();

    public void addVertex(Vertex v) {
        vertices.putIfAbsent(v, v);
    }

    public void addEdge(Vertex from, Vertex to, double weight) {
        addVertex(from);
        addVertex(to);
        vertices.get(from).addNeighbor(to, weight);
        vertices.get(to).addNeighbor(from, weight); // If undirected
    }

    public Set<Vertex> getVertices() {
        return vertices.keySet();
    }

    public Map<Vertex, Double> getNeighbors(Vertex v) {
        return vertices.get(v).getNeighbors();
    }
}