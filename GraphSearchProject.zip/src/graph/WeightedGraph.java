package graph;

import java.util.*;

public class WeightedGraph {
    private Map<String, Vertex> vertices = new HashMap<>();

    public Vertex getOrCreateVertex(String label) {
        return vertices.computeIfAbsent(label, Vertex::new);
    }

    public void addEdge(String from, String to, double weight) {
        Vertex v1 = getOrCreateVertex(from);
        Vertex v2 = getOrCreateVertex(to);
        v1.addNeighbor(v2, weight);
        v2.addNeighbor(v1, weight); // If undirected
    }

    public Vertex getVertex(String label) {
        return vertices.get(label);
    }

    public Collection<Vertex> getVertices() {
        return vertices.values();
    }
}