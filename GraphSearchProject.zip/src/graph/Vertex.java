package graph;

import java.util.*;

public class Vertex {
    private String label;
    private Map<Vertex, Double> neighbors;

    public Vertex(String label) {
        this.label = label;
        this.neighbors = new HashMap<>();
    }

    public String getLabel() {
        return label;
    }

    public void addNeighbor(Vertex vertex, double weight) {
        neighbors.put(vertex, weight);
    }

    public Map<Vertex, Double> getNeighbors() {
        return neighbors;
    }

    @Override
    public String toString() {
        return label;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Vertex other) {
            return label.equals(other.label);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(label);
    }
}