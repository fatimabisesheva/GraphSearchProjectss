import java.util.List;

public class Main {
    public static void main(String[] args) {
        Vertex A = new Vertex("A");
        Vertex B = new Vertex("B");
        Vertex C = new Vertex("C");
        Vertex D = new Vertex("D");
        Vertex E = new Vertex("E");

        WeightedGraph graph = new WeightedGraph();
        graph.addEdge(A, B, 4);
        graph.addEdge(A, C, 2);
        graph.addEdge(B, C, 5);
        graph.addEdge(B, D, 10);
        graph.addEdge(C, E, 3);
        graph.addEdge(E, D, 4);
        graph.addEdge(D, A, 7);

        System.out.println("BFS Path:");
        Search bfs = new BreadthFirstSearch(graph, A, D);
        List<Vertex> pathBFS = bfs.getPath();
        if (pathBFS != null) pathBFS.forEach(v -> System.out.print(v + " "));
        else System.out.println("No path found");

        System.out.println("

Dijkstra Path:");
        Search dijkstra = new DijkstraSearch(graph, A, D);
        List<Vertex> pathDijkstra = dijkstra.getPath();
        if (pathDijkstra != null) pathDijkstra.forEach(v -> System.out.print(v + " "));
        else System.out.println("No path found");
    }
}