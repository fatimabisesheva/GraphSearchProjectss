import java.util.*;

public class DijkstraSearch extends Search {
    private Map<Vertex, Double> distTo = new HashMap<>();
    private Map<Vertex, Vertex> edgeTo = new HashMap<>();
    private PriorityQueue<Vertex> pq;

    public DijkstraSearch(WeightedGraph graph, Vertex source, Vertex goal) {
        super(source, goal);
        pq = new PriorityQueue<>(Comparator.comparingDouble(distTo::get));
        for (Vertex v : graph.getVertices()) {
            distTo.put(v, Double.POSITIVE_INFINITY);
        }
        distTo.put(source, 0.0);
        pq.add(source);

        while (!pq.isEmpty()) {
            Vertex v = pq.poll();
            for (Map.Entry<Vertex, Double> entry : graph.getNeighbors(v).entrySet()) {
                relax(v, entry.getKey(), entry.getValue());
            }
        }
    }

    private void relax(Vertex u, Vertex v, double weight) {
        double dist = distTo.get(u) + weight;
        if (dist < distTo.get(v)) {
            distTo.put(v, dist);
            edgeTo.put(v, u);
            pq.remove(v);
            pq.add(v);
        }
    }

    @Override
    public List<Vertex> getPath() {
        List<Vertex> path = new ArrayList<>();
        if (!distTo.containsKey(goal) || distTo.get(goal) == Double.POSITIVE_INFINITY) return null;

        for (Vertex at = goal; at != null; at = edgeTo.get(at)) {
            path.add(at);
        }
        Collections.reverse(path);
        return path;
    }
}