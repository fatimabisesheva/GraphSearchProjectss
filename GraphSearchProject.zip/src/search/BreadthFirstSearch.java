package search;

import graph.Vertex;

import java.util.*;

public class BreadthFirstSearch extends Search {
    private Map<Vertex, Vertex> edgeTo = new HashMap<>();
    private Set<Vertex> visited = new HashSet<>();

    public BreadthFirstSearch(Vertex source, Vertex goal) {
        super(source, goal);
        bfs();
    }

    private void bfs() {
        Queue<Vertex> queue = new LinkedList<>();
        queue.add(source);
        visited.add(source);

        while (!queue.isEmpty()) {
            Vertex current = queue.poll();
            if (current.equals(goal)) break;

            for (Vertex neighbor : current.getNeighbors().keySet()) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    edgeTo.put(neighbor, current);
                    queue.add(neighbor);
                }
            }
        }
    }

    @Override
    public boolean hasPathTo() {
        return visited.contains(goal);
    }

    @Override
    public List<Vertex> pathTo() {
        if (!hasPathTo()) return null;

        List<Vertex> path = new ArrayList<>();
        for (Vertex v = goal; v != null; v = edgeTo.get(v)) {
            path.add(v);
        }
        Collections.reverse(path);
        return path;
    }
}