package search;

import graph.Vertex;

import java.util.List;

public abstract class Search {
    protected final Vertex source;
    protected final Vertex goal;

    public Search(Vertex source, Vertex goal) {
        this.source = source;
        this.goal = goal;
    }

    public abstract boolean hasPathTo();

    public abstract List<Vertex> pathTo();
}