package search;

import graph.Vertex;

import java.util.*;

public class DijkstraSearch extends Search {
    private final Map<Vertex, Double> distTo = new HashMap<>();
    private final Map<Vertex, Vertex> edgeTo = new HashMap<>();

    public DijkstraSearch(Vertex source, Vertex goal) {
        super(source, goal);
        dijkstra();
    }

    private void dijkstra() {
        PriorityQueue<Vertex> pq = new PriorityQueue<>(Comparator.comparingDouble(distTo::get));
        distTo.put(source, 0.0);
        pq.add(source);

        while (!pq.isEmpty()) {
            Vertex current = pq.poll();

            if (current.equals(goal)) break;

            for (Map.Entry<Vertex, Double> entry : current.getNeighbors().entrySet()) {
                Vertex neighbor = entry.getKey();
                double weight = entry.getValue();
                double newDist = distTo.get(current) + weight;

                if (newDist < distTo.getOrDefault(neighbor, Double.POSITIVE_INFINITY)) {
                    distTo.put(neighbor, newDist);
                    edgeTo.put(neighbor, current);
                    pq.remove(neighbor);
                    pq.add(neighbor);
                }
            }
        }
    }

    @Override
    public boolean hasPathTo() {
        return distTo.containsKey(goal);
    }

    @Override
    public List<Vertex> pathTo() {
        if (!hasPathTo()) return null;

        List<Vertex> path = new ArrayList<>();
        for (Vertex v = goal; v != null; v = edgeTo.get(v)) {
            path.add(v);
        }
        Collections.reverse(path);
        return path;
    }
}