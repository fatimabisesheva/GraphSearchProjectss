import java.util.*;

public class BreadthFirstSearch extends Search {
    private Map<Vertex, Vertex> edgeTo = new HashMap<>();
    private Set<Vertex> marked = new HashSet<>();

    public BreadthFirstSearch(WeightedGraph graph, Vertex source, Vertex goal) {
        super(source, goal);
        bfs(graph, source);
    }

    private void bfs(WeightedGraph graph, Vertex start) {
        Queue<Vertex> queue = new LinkedList<>();
        marked.add(start);
        queue.add(start);

        while (!queue.isEmpty()) {
            Vertex v = queue.poll();
            for (Vertex w : graph.getNeighbors(v).keySet()) {
                if (!marked.contains(w)) {
                    edgeTo.put(w, v);
                    marked.add(w);
                    queue.add(w);
                }
            }
        }
    }

    @Override
    public List<Vertex> getPath() {
        if (!marked.contains(goal)) return null;

        List<Vertex> path = new ArrayList<>();
        for (Vertex x = goal; x != null; x = edgeTo.get(x)) {
            path.add(x);
        }
        Collections.reverse(path);
        return path;
    }
}