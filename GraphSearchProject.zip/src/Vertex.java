import java.util.*;

public class Vertex {
    private String name;
    private Map<Vertex, Double> neighbors;

    public Vertex(String name) {
        this.name = name;
        this.neighbors = new HashMap<>();
    }

    public String getName() {
        return name;
    }

    public void addNeighbor(Vertex neighbor, double weight) {
        neighbors.put(neighbor, weight);
    }

    public Map<Vertex, Double> getNeighbors() {
        return neighbors;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Vertex)) return false;
        Vertex other = (Vertex) obj;
        return Objects.equals(name, other.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}