import java.util.List;

public abstract class Search {
    protected Vertex source;
    protected Vertex goal;

    public Search(Vertex source, Vertex goal) {
        this.source = source;
        this.goal = goal;
    }

    public abstract List<Vertex> getPath();
}